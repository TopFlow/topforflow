#!/bin/sh
#
# Choose nearest stratum:
#       stratum-ru.rplant.xyz   /Moscow/
#       stratum-eu.rplant.xyz   /London/
#       stratum-asia.rplant.xyz /Singapore/
#
while [ 1 ]; do
./cpuminer-sse2 -a yespowerRES -o stratum+tcps://stratum-ru.rplant.xyz:17040 -u r14V4fy4Awm6QHxTN8wTXQPAdryq66cRd4X.Linux_Rigs
sleep 5
done
