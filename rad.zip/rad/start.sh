#! /bin/bash
export LD_LIBRARY_PATH=/usr/local/cuda/lib64/:/usr/local/cuda/lib64/stubs:./:$LD_LIBRARY_PATH
export LIBRARY_PATH=/usr/local/cuda/lib64/:/usr/local/cuda/lib64/stubs:./:$LIBRARY_PATH
export PATH=/usr/local/go/bin:/usr/local/cuda/bin/:$PATH
NVIDIA_COUNT=`nvidia-smi -L | wc -l`
echo "there has "$NVIDIA_COUNT "gpu"
str=""
for ((i=0; i < $NVIDIA_COUNT; i++))
do
 str=$str$i
 if [ $i -lt $[$NVIDIA_COUNT - 1] ]; then
  str=$str,
 fi
done

worker='RTX1'
pool_uri='cuckoo.cortexmint.com:8008'
pool_uri_1='cuckoo.cortexmint.com:8008'
pool_uri_2='cuckoo.cortexmint.com:8008'
device=$str
account='0x80f4e1349e3ca7f71e45f52f1606d5cfb3911b0f'
start='./miner -pool_uri='$pool_uri' -pool_uri_1='$pool_uri_1' -pool_uri_2='$pool_uri_2' -worker='$worker' -devices='$device' -account='$account' -2080ti'
echo $start
$start
