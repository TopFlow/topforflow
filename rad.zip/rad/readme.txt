### Radiance Miner
1. Now 7.2G of VRAM would be enough, which making mid end mining GPUs like NVIDIA 1080 and P104 able to mine CTXC. 

### v3.0.0beta features
1. improve performance on 1080ti, 2080ti

### How To Run
1. modify the start.sh
	-worker: the worker name
	-pool_uri: the remote pool uri, example:cuc only supports NVIDIA 8G GPU on windows systemkoo.cortexmint.com:8008
	-device: the gpu ids you want to mining
	-account: your cortex wallet address	
    -8g: if you use a 8GB memory GPU
    -11g: for 1080ti or other 11G GPU
    -2080ti: for 2080ti
2. bash start.sh
