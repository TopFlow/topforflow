### Radiance Miner
1. Now 7.2G of VRAM would be enough, which making mid end mining GPUs like NVIDIA 1080 and P104 able to mine CTXC. 

### v1.0.1 features
1. supports NVIDIA 8G and 11G GPU on linux system
2. only supports NVIDIA 8G GPU on windows system 
3. Haven't considered developing under OpenCL, might consider if Radiance gets popular

### How To Run
1. modify the start.sh
	-worker: the worker name
	-pool_uri: the remote pool uri, example:cuc only supports NVIDIA 8G GPU on windows systemkoo.cortexmint.com:8008
	-device: the gpu ids you want to mining
	-account: your cortex wallet address	
    -8g: if you use a 8GB memory GPU
    -11g: if you use a 11GB memory GPU
2. bash start.sh
