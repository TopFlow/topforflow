#!/bin/sh
while [ 1 ]; do
./resminer-sse2 -o stratum+tcp://stratum.rplant.xyz:7040 -u r1KjMqzfBS1zL9AnqCp3YdfN9v4ouw5GeEc.1
done
